package mt.edu.mcast.listadapterexample;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

public class MovieListAdapter extends ListAdapter<Movie, MovieListAdapter.MovieViewHolder> {

    MovieClickInterface movieClickInterface;
    Context ctx;

    protected MovieListAdapter(@NonNull DiffUtil.ItemCallback<Movie> diffCallback, MovieClickInterface clickInterface) {
        super(diffCallback);
        movieClickInterface = clickInterface;
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ctx = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(ctx);
        return new MovieViewHolder(inflater.inflate(R.layout.movie_recyclerview_row,
                parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder holder, int position) {

        Movie m = getItem(position);
        holder.bind(m);

   }

    class MovieViewHolder extends RecyclerView.ViewHolder{

        TextView txtvTitle;
        TextView txtvRating;
        ImageButton iBtnDel;

        public MovieViewHolder(@NonNull View itemView) {
            super(itemView);


            txtvTitle = itemView.findViewById(R.id.txtvTitle);
            txtvRating = itemView.findViewById(R.id.txtvRating);
            iBtnDel = itemView.findViewById(R.id.iBtnDel);

            iBtnDel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                   movieClickInterface.onDelete(getAdapterPosition());

                }
            });
        }

        public void bind(Movie m){

            Animation anim = AnimationUtils.loadAnimation(ctx, R.anim.slide);
            itemView.startAnimation(anim);

            txtvTitle.setText(m.getTitle());
            txtvRating.setText(m.getRating());
        }
    }// MovieViewHolder

    interface MovieClickInterface{
        public void onDelete(int position);
    }
}
