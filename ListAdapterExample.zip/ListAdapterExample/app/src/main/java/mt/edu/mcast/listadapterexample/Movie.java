package mt.edu.mcast.listadapterexample;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;

import java.util.Objects;
import java.util.UUID;

public class Movie {

    private String id;
    private String title;
    private String rating;

    public Movie(String title, String rating) {
        this.id = UUID.randomUUID().toString();
        this.title = title;
        this.rating = rating;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (!(o instanceof Movie)) return false;

        Movie movie = (Movie) o;
        return getId().equals(movie.getId()) &&
                getTitle().equals(movie.getTitle()) &&
                getRating().equals(movie.getRating());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getTitle(), getRating());
    }

    @Override
    public String toString() {
        return "Movie{" +
                "id='" + id + '\'' +
                ", title='" + title + '\'' +
                ", rating='" + rating + '\'' +
                '}';
    }

    public static DiffUtil.ItemCallback<Movie> itemCallback = new DiffUtil.ItemCallback<Movie>() {
        @Override
        public boolean areItemsTheSame(@NonNull Movie oldItem, @NonNull Movie newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Movie oldItem, @NonNull Movie newItem) {
            return oldItem.equals(newItem);
        }
    };
}
