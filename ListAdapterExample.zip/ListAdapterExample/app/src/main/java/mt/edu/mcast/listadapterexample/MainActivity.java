package mt.edu.mcast.listadapterexample;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.OvershootInterpolator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements MovieListAdapter.MovieClickInterface {

    MovieListAdapter movieListAdapter;
    MovieViewModel movieViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView rcView = findViewById(R.id.rcView);
        rcView.setLayoutManager(new LinearLayoutManager(this));
        rcView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        movieListAdapter = new MovieListAdapter(Movie.itemCallback, this);
        rcView.setAdapter(movieListAdapter);

        movieViewModel = new ViewModelProvider(this).get(MovieViewModel.class);
        movieViewModel.getMovieList().observe(this, new Observer<List<Movie>>() {
            @Override
            public void onChanged(List<Movie> movies) {
                movieListAdapter.submitList(movies);
            }
        });


    }



    public void add(View v){

        Movie m = new Movie("Good Fellas", "8.7");
        movieViewModel.addMovie(m);

    }

    public void update(View v){
        Random rand = new Random();
        List<Movie> movies = new ArrayList<>(movieListAdapter.getCurrentList());

        int pos = rand.nextInt(movies.size());
        Movie oldMovie = movies.get(pos);

        Movie updatedMovie = new Movie(oldMovie.getTitle(),
                String.valueOf(rand.nextInt(11)));
        updatedMovie.setId(oldMovie.getId());


       movieViewModel.updateMovie(updatedMovie, pos);


    }

    @Override
    public void onDelete(int position) {
        movieViewModel.deleteMovie(position);
    }
}