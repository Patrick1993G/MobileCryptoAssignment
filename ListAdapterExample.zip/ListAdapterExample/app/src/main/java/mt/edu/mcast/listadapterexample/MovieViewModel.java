package mt.edu.mcast.listadapterexample;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.LiveData;

import java.util.ArrayList;
import java.util.List;

public class MovieViewModel extends ViewModel {

    private MutableLiveData<List<Movie>> mutableLiveData;

    public LiveData<List<Movie>> getMovieList(){

        if(mutableLiveData == null){
            mutableLiveData = new MutableLiveData<>();

            initMovieList();
        }

        return mutableLiveData;

    }

    private void initMovieList(){
        List<Movie> movieList = new ArrayList<>();
        movieList.add(new Movie("The Godfather", "9.2"));
        movieList.add(new Movie("Pulp Fiction", "8.9"));
        movieList.add(new Movie("Scarface", "8.3"));

        mutableLiveData.setValue(movieList);
    }

    public void addMovie(Movie m){

        if(mutableLiveData.getValue() != null){
            List<Movie> movies = new ArrayList<>(mutableLiveData.getValue());
            movies.add(m);
            mutableLiveData.setValue(movies);
        }

    }

    public void updateMovie(Movie m, int pos){
        if(mutableLiveData.getValue() != null){
            List<Movie> movies = new ArrayList<>(mutableLiveData.getValue());
            movies.remove(pos);
            movies.add(pos, m);
            mutableLiveData.setValue(movies);
        }
    }

    public void deleteMovie(int pos){
        if(mutableLiveData.getValue() != null){
            List<Movie> movies = new ArrayList<>(mutableLiveData.getValue());
            movies.remove(pos);
            mutableLiveData.setValue(movies);
        }
    }

}
